main()
{
    return(0);
}
